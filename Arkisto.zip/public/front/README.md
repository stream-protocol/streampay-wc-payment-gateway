# StreamPay Front End

## Usage
Run the following command from the _front/_ directory root.

### Build for Development

```
npm run dev
# or
yarn dev
```

### Build for Production

```
npm run build
# or
yarn build
```

