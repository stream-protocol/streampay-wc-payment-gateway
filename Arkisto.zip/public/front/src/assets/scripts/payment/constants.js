export const TESTING_CLUSTER = "devnet";
export const MAIN_CLUSTER = "mainnet-beta";

export const DUMMY_TOKEN_KEY = "Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr";
export const USDC_TOKEN_KEY = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
