import "./assets/styles/app.scss";

import "./assets/scripts/ajax-complete";
import "./assets/scripts/payment/payment";
